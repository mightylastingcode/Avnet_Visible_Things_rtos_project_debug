#include "pmod2_run_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>



/* PMOD2 Run Thread entry function */
void pmod2_run_thread_entry(void)
{
    ULONG event_flags;

    tx_event_flags_get(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_AND, &event_flags, TX_WAIT_FOREVER);  // Don't clear it. Leave it enabled for other threads.

    //write_pmode_gpio_type1_byte_port (2, 0xE3);
    //write_pmode_gpio_type1_byte_port (2, 0xCA);

    //write_pmode_gpio_type1_byte_port (2, 0xE3);  // for PMOD[1:6] IO<5> (P00x) is only input mode allowed by S7G2.
    //write_pmode_gpio_type1_byte_port (3, 0x64);
    //write_pmode_gpio_type1_byte_port (4, 0xCB);
    //write_pmode_gpio_type1_byte_port (5, 0x27);
    //write_pmode_gpio_type1_byte_port (6, 0x05);

     while (true)
     {
         tx_mutex_get(&g_gpio_lock_mutex, TX_WAIT_FOREVER);
         write_pmode_gpio_type1_byte_port (2, 0x28);
         tx_mutex_put(&g_gpio_lock_mutex);

         tx_thread_sleep(10);

         tx_mutex_get(&g_gpio_lock_mutex, TX_WAIT_FOREVER);
         write_pmode_gpio_type1_byte_port (2, 0x8B);
         tx_mutex_put(&g_gpio_lock_mutex);

         tx_thread_sleep(10);

     }

}

