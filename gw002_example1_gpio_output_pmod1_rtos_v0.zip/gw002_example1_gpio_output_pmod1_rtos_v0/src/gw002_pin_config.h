#ifndef GW002_PIN_CONFIG_H
#define GW002_PIN_CONFIG_H


/*MCU Pins*/
#define     NFC_IRQ_PIN                 IOPORT_PORT_00_PIN_00   /*  NFC Interrupt pin. Active level configurable  */
#define     PMOD2_INT_PIN               IOPORT_PORT_00_PIN_01   /*  PMOD2 Interrupt pin  */
#define     PMOD3_INT_PIN               IOPORT_PORT_00_PIN_02   /*  PMOD3 Interrupt pin  */

#define     PMOD4_INT_PIN               IOPORT_PORT_00_PIN_04   /*  PMOD4 Interrupt pin  */
#define     PMOD6_INT_PIN               IOPORT_PORT_00_PIN_05   /*  PMOD6 Interrupt pin  */
#define     PMOD5_INT_PIN               IOPORT_PORT_00_PIN_06   /*  PMOD5 Interrupt pin  */
#define     NFC_BUSY_READY_PIN          IOPORT_PORT_00_PIN_07   /*  NFC Busy signal  */
#define     IO_EXPANDER_INT_PIN         IOPORT_PORT_00_PIN_08   /*  IO Expanders Interrupt. Active low  */
#define     LCD_TOUCH_INT_PIN           IOPORT_PORT_00_PIN_09   /*  LCD Touch Pannel Interrupt. Active Low. Warning : Shared with WIFI interrupt  */
#define     ETH_IRQ_PIN                 IOPORT_PORT_00_PIN_10   /*  Ethernet Switch Interrupt. Active level configurable  */
#define     P011_AN104_AUDIO_PIN        IOPORT_PORT_00_PIN_11   /*  Audio Microphone Analog Input.   */
#define     AUDIO_DAC_PIN               IOPORT_PORT_00_PIN_14   /*  Audio Speaker Analog Output  */
#define     WL_IRQ_PIN                  IOPORT_PORT_00_PIN_15   /*  WIFI Interrupt. Warning : Shared with LCD Touch Pannel Interrupt  */
#define     DQ00_PIN                    IOPORT_PORT_01_PIN_00   /*  External SDRAM DATA 0  */
#define     DQ01_PIN                    IOPORT_PORT_01_PIN_01   /*  External SDRAM DATA 1  */
#define     DQ02_PIN                    IOPORT_PORT_01_PIN_02   /*  External SDRAM DATA 2  */
#define     DQ03_PIN                    IOPORT_PORT_01_PIN_03   /*  External SDRAM DATA 3  */
#define     DQ04_PIN                    IOPORT_PORT_01_PIN_04   /*  External SDRAM DATA 4  */
#define     DQ05_PIN                    IOPORT_PORT_01_PIN_05   /*  External SDRAM DATA 5  */
#define     DQ06_PIN                    IOPORT_PORT_01_PIN_06   /*  External SDRAM DATA 6  */
#define     DQ07_PIN                    IOPORT_PORT_01_PIN_07   /*  External SDRAM DATA 7  */
#define     TMS_SWDIO_PIN               IOPORT_PORT_01_PIN_08   /*  Debug Serial IO / JTAG TMS  */
#define     TDO_SWO_PIN                 IOPORT_PORT_01_PIN_09   /*  Debug Serial Wire Out / JTAG TDO  */
#define     TDI_PIN                     IOPORT_PORT_01_PIN_10   /*  BT_Host_Wake  */
#define     A05_PIN                     IOPORT_PORT_01_PIN_11   /*  External SDRAM Address 5  */
#define     A04_PIN                     IOPORT_PORT_01_PIN_12   /*  External SDRAM Address 4  */
#define     A03_PIN                     IOPORT_PORT_01_PIN_13   /*  External SDRAM Address 3  */
#define     A02_PIN                     IOPORT_PORT_01_PIN_14   /*  External SDRAM Address 2  */
#define     A01_PIN                     IOPORT_PORT_01_PIN_15   /*  External SDRAM Address 1  */
#define     NMI_PIN                     IOPORT_PORT_02_PIN_00   /*  Non-maskable interrupt request pin.  */
#define     MD_PIN                      IOPORT_PORT_02_PIN_01   /*  Pins for setting the operating mode. The signal levels on these pins must not be changed during operation mode transition on release from the reset state.  */
#define     MISOB_A_PIN                 IOPORT_PORT_02_PIN_02   /*  PMOD5 / Serial Flash MISO SPI  */
#define     MOSIB_A_PIN                 IOPORT_PORT_02_PIN_03   /*  PMOD5 / Serial Flash MOSI SPI  */
#define     RSPCKB_A_PIN                IOPORT_PORT_02_PIN_04   /*  PMOD5 / Serial Flash CLK SPI  */
#define     SCL1_A_PIN                  IOPORT_PORT_02_PIN_05   /*  PMOD6 I2C SCL  */
#define     SDA1_A_PIN                  IOPORT_PORT_02_PIN_06   /*  PMOD6 I2C SDA  */
#define     WL_CS_PIN                   IOPORT_PORT_02_PIN_07   /*  WIFI Chip Select. Active low (Uses RSPI 1 CS2)  */
#define     EXTAL_PIN                   IOPORT_PORT_02_PIN_12   /*  High-Frequency XTAL  */
#define     XTAL_PIN                    IOPORT_PORT_02_PIN_13   /*  High-Frequency XTAL  */
#define     TCK_SWCLK_PIN               IOPORT_PORT_03_PIN_00   /*  Debug Serial Wire Clock / JTAG Clock  */
#define     A06_PIN                     IOPORT_PORT_03_PIN_01   /*  External SDRAM Address 6  */
#define     A07_PIN                     IOPORT_PORT_03_PIN_02   /*  External SDRAM Address 7  */
#define     A08_PIN                     IOPORT_PORT_03_PIN_03   /*  External SDRAM Address 8  */
#define     A09_PIN                     IOPORT_PORT_03_PIN_04   /*  External SDRAM Address 9  */
#define     A10_PIN                     IOPORT_PORT_03_PIN_05   /*  External SDRAM Address 10  */
#define     A11_PIN                     IOPORT_PORT_03_PIN_06   /*  External SDRAM Address 11  */
#define     A12_PIN                     IOPORT_PORT_03_PIN_07   /*  External SDRAM Address 12  */
#define     A13_PIN                     IOPORT_PORT_03_PIN_08   /*  External SDRAM Address 13  */
#define     A14_PIN                     IOPORT_PORT_03_PIN_09   /*  External SDRAM Address 14  */
#define     A15_PIN                     IOPORT_PORT_03_PIN_10   /*  External SDRAM Address 15  */
#define     RAS_PIN                     IOPORT_PORT_03_PIN_11   /*  External SDRAM low address strobe signal, active LOW.  */
#define     CAS_PIN                     IOPORT_PORT_03_PIN_12   /*  External SDRAM column address strobe signal, active LOW.  */
#define     LED3_PIN                    IOPORT_PORT_03_PIN_13   /*  LED 3 (Orange). Active High  */
#define     LED4_PIN                    IOPORT_PORT_03_PIN_14   /*  LED 4 (Red). Active High  */
#define     LCD_DE_PIN                  IOPORT_PORT_03_PIN_15   /*  LCD Display Enable. Active High  */
#define     PMOD1_INT_PIN               IOPORT_PORT_04_PIN_00   /*  PMOD1 Interrupt pin  */
#define     ET0_MDC_PIN                 IOPORT_PORT_04_PIN_01   /*  Ethernet Switch SMI bus. MDC pin  */
#define     ET0_MDIO_PIN                IOPORT_PORT_04_PIN_02   /*  Ethernet Switch SMI bus. MDIO pin  */
#define     PIXD7_PIN                   IOPORT_PORT_04_PIN_03   /*  CAMERA PIXEL DATA 7  */
#define     PIXD6_PIN                   IOPORT_PORT_04_PIN_04   /*  CAMERA PIXEL DATA 6  */
#define     PIXD5_PIN                   IOPORT_PORT_04_PIN_05   /*  CAMERA PIXEL DATA 5  */
#define     PIXD4_PIN                   IOPORT_PORT_04_PIN_06   /*  CAMERA PIXEL DATA 4  */
#define     USB_VBUS_PIN                IOPORT_PORT_04_PIN_07   /*  USB Device Full-Speed. VBUS detection  */
#define     RMII0_CRS_DV_PIN            IOPORT_PORT_04_PIN_08   /*  Ethernet Switch Carrier Receive Signal/Data Valid  */
#define     RMII0_RX_ER_PIN             IOPORT_PORT_04_PIN_09   /*  Ethernet RX error (Not used with a switch configuration)  */
#define     RMII0_RXD1_PIN              IOPORT_PORT_04_PIN_10   /*  Ethernet RX Data 1. RMII  */
#define     RMII0_RXD0_PIN              IOPORT_PORT_04_PIN_11   /*  Ethernet RX Data 0. RMII  */
#define     REF50CK0_PIN                IOPORT_PORT_04_PIN_12   /*  Ethernet 50MHz reference clock 0. RMII  */
#define     RMII0_TXD0_PIN              IOPORT_PORT_04_PIN_13   /*  Ethernet TX Data 0. RMII  */
#define     RMII0_TXD1_PIN              IOPORT_PORT_04_PIN_14   /*  Ethernet TX Data 1. RMII  */
#define     RMII0_TXD_EN_PIN            IOPORT_PORT_04_PIN_15   /*  Ethernet TX Data Enable.RMII  */
#define     SD1CLK_PIN                  IOPORT_PORT_05_PIN_00   /*  SDIO Clock  */
#define     SD1CMD_PIN                  IOPORT_PORT_05_PIN_01   /*  SDIO Command/Response  */
#define     SD1DAT0_PIN                 IOPORT_PORT_05_PIN_02   /*  SDIO DATA 0  */
#define     SD1DAT1_PIN                 IOPORT_PORT_05_PIN_03   /*  SDIO DATA 1  */
#define     SD1DAT2_PIN                 IOPORT_PORT_05_PIN_04   /*  SDIO DATA 2  */
#define     SD1DAT3_PIN                 IOPORT_PORT_05_PIN_05   /*  SDIO DATA 3  */
#define     SD1CD_PIN                   IOPORT_PORT_05_PIN_06   /*  SDIO Card Detection. Used for µSD Card detection  */
#define     CTS5_RTS5_B_SS5_B_PIN       IOPORT_PORT_05_PIN_07   /*  WIFI/BT Module, BT UART CTS  */
#define     SCK5_B_PIN                  IOPORT_PORT_05_PIN_08   /*  PMOD 5 SPI /Synchronous UART Clock  */
#define     TXD5_B_MOSI5_B_SDA5_B_PIN   IOPORT_PORT_05_PIN_09   /*  WIFI/BT Module : UART TX\
                                                                                    PMOD 5: UART TX / SPI MOSI / I2C SDA  */
#define     RXD5_B_MISO5_B_SCL5_B_PIN   IOPORT_PORT_05_PIN_10   /*  WIFI/BT Module : UART RX\
                                                                                    PMOD5: UART RX / SPI MISO / I2C SCL  */
#define     PCKO_PIN                    IOPORT_PORT_05_PIN_11   /*  CAMERA Pixel Clock Output  */
#define     VSYNC_PIN                   IOPORT_PORT_05_PIN_12   /*  CAMERA Vertical Synchro.  */
#define     MCU_PMOD5_IO8_PIN           IOPORT_PORT_05_PIN_13   /*  PMOD 5 General Purpose I/O 8  */
#define     MCU_PMOD4_CS_IO1_PIN        IOPORT_PORT_05_PIN_14   /*  PMOD 4 :\
                                                                                - UART mode: General Purpose I/O#1\
                                                                                - SPI mode : SPI Chip Select  */

#define     MCU_PMOD5_SPI_CS_PIN        IOPORT_PORT_05_PIN_15   /*  PMOD 5 SPI Chip Select  */
#define     NFC_AUX2_DWL_REQ_PIN        IOPORT_PORT_06_PIN_00   /*  NFC Analog test bus or Download request  */
#define     DQM0_PIN                    IOPORT_PORT_06_PIN_01   /*  External SDRAM I/O data mask enable signal for DQ07 to DQ00.  */
#define     SDCLK_PIN                   IOPORT_PORT_06_PIN_02   /*  External SDRAM Clock.  */
#define     DQ13_PIN                    IOPORT_PORT_06_PIN_03   /*  External SDRAM DATA 13  */
#define     DQ12_PIN                    IOPORT_PORT_06_PIN_04   /*  External SDRAM DATA 12  */
#define     DQ11_PIN                    IOPORT_PORT_06_PIN_05   /*  External SDRAM DATA 11  */
#define     LCD_DATA03_B_PIN            IOPORT_PORT_06_PIN_06   /*  LCD MODULE DATA (B6). RGB565  */
#define     LCD_DATA04_B_PIN            IOPORT_PORT_06_PIN_07   /*  LCD MODULE DATA (B7). RGB565  */
#define     A00_DQM1_PIN                IOPORT_PORT_06_PIN_08   /*  External SDRAM I/O data mask enable signal for DQ15 to DQ08.  */
#define     CKE_PIN                     IOPORT_PORT_06_PIN_09   /*  External SDRAM clock enable signal.  */
#define     WE_PIN                      IOPORT_PORT_06_PIN_10   /*  External SDRAM write enable signal, active LOW.  */
#define     SDCS_PIN                    IOPORT_PORT_06_PIN_11   /*  External SDRAM chip select signal, active LOW.  */
#define     DQ08_PIN                    IOPORT_PORT_06_PIN_12   /*  External SDRAM DATA 08  */
#define     DQ09_PIN                    IOPORT_PORT_06_PIN_13   /*  External SDRAM DATA 09  */
#define     DQ10_PIN                    IOPORT_PORT_06_PIN_14   /*  External SDRAM DATA 10  */
#define     LCD_DATA10_B_PIN            IOPORT_PORT_06_PIN_15   /*  LCD MODULE DATA (G7). RGB565  */
#define     PIXD3_PIN                   IOPORT_PORT_07_PIN_00   /*  CAMERA PIXEL DATA 3  */
#define     PIXD2_PIN                   IOPORT_PORT_07_PIN_01   /*  CAMERA PIXEL DATA 2  */
#define     PIXD1_PIN                   IOPORT_PORT_07_PIN_02   /*  CAMERA PIXEL DATA 1  */
#define     PIXD0_PIN                   IOPORT_PORT_07_PIN_03   /*  CAMERA PIXEL DATA 0  */
#define     HSYNC_PIN                   IOPORT_PORT_07_PIN_04   /*  CAMERA Horizontal Synchro.  */
#define     PIXCLK_PIN                  IOPORT_PORT_07_PIN_05   /*  CAMERA PIXEL Clock  */

#define     RXD3_B_MISO3_B_SCL3_B_PIN   IOPORT_PORT_07_PIN_06   /*  BOARD I2C BUS SCL.\
                                                                                Shared with :\
                                                                                   - Camera SCCB\
                                                                                   - Ethernet Switch\
                                                                                   - IO-Expanders\
                                                                                   - LCD Touch Panel\
                                                                                   - Secure Elements  */

#define     TXD3_B_MOSI3_B_SDA3_B_PIN   IOPORT_PORT_07_PIN_07   /*  BOARD I2C BUS SDA.\
                                                                                Shared with :\
                                                                                   - Camera SCCB\
                                                                                   - Ethernet Switch\
                                                                                   - IO-Expanders\
                                                                                   - LCD Touch Panel\
                                                                                   - Secure Elements  */

#define     RXD1_B_MISO1_B_SCL1_B_PIN   IOPORT_PORT_07_PIN_08   /*  PMOD 3: UART RX / SPI MISO / I2C SCL  */
#define     TXD1_B_MOSI1_B_SDA1_B_PIN   IOPORT_PORT_07_PIN_09   /*  PMOD 3: UART TX / SPI MOSI / I2C SDA  */
#define     SCK1_B_PIN                  IOPORT_PORT_07_PIN_10   /*  PMOD 3: SPI SCK /Synchronous UART Clock  */
#define     CTS1_RTS1_B_SS1_B_PIN       IOPORT_PORT_07_PIN_11   /*  PMOD 3: SPI CS  */
#define     GTIOC2B_B_BCKL_DIM_PIN      IOPORT_PORT_07_PIN_12   /*  LCD Backlight PWM signal for dimming.  */
#define     GTIOC2A_B_SPK_VOLUME_PIN    IOPORT_PORT_07_PIN_13   /*  Speaker Volume PWM signal.  */
#define     DQ14_PIN                    IOPORT_PORT_08_PIN_00   /*  External SDRAM DATA 14  */
#define     DQ15_PIN                    IOPORT_PORT_08_PIN_01   /*  External SDRAM DATA 15  */
#define     LCD_DATA02_B_PIN            IOPORT_PORT_08_PIN_02   /*  LCD MODULE DATA (B5). RGB565  */
#define     LCD_DATA01_B_PIN            IOPORT_PORT_08_PIN_03   /*  LCD MODULE DATA (B4). RGB565  */
#define     LCD_DATA00_B_PIN            IOPORT_PORT_08_PIN_04   /*  LCD MODULE DATA (B3). RGB565  */
#define     PMOD5_RST_PIN               IOPORT_PORT_08_PIN_05   /*  PMOD 5 Reset.  */
#define     ETH_RST_PIN                 IOPORT_PORT_08_PIN_06   /*  Ethernet Switch Reset  */
#define     BCKL_EN_PIN                 IOPORT_PORT_08_PIN_07   /*  LCD Backlight Enable signal. Active High  */
#define     CAM_RESET_PIN               IOPORT_PORT_08_PIN_08   /*  CAMERA Reset Signal.  */
#define     MCU_PMOD6_IO1_PIN           IOPORT_PORT_08_PIN_09   /*  PMOD6 GPIO 1  */
#define     MCU_PMOD6_IO2_PIN           IOPORT_PORT_08_PIN_10   /*  PMOD6 GPIO 2  */
#define     CTX0_C_PIN                  IOPORT_PORT_08_PIN_11   /*  CAN Controller TX pin  */
#define     CRX0_C_PIN                  IOPORT_PORT_08_PIN_12   /*  CAN Controller RX pin  */
#define     TDATA3_PIN                  IOPORT_PORT_08_PIN_13   /*  Debug Trace Data 3  */
#define     LCD_CLK_B_PIN               IOPORT_PORT_09_PIN_00   /*  LCD MODULE CLOCK  */
#define     LCD_DATA15_B_PIN            IOPORT_PORT_09_PIN_01   /*  LCD MODULE DATA (R7). RGB565  */
#define     BT_DEV_WAKE_PIN             IOPORT_PORT_09_PIN_02   /*  BlueTooth Device Wake-up.  */
#define     NFC_RESET_PIN               IOPORT_PORT_09_PIN_03   /*  NFC RESET Signal. Active Low  */
#define     ISO7816_EN_PIN              IOPORT_PORT_09_PIN_04   /*  ISO 7816 Enable signal. Active Low.\
                                                                        Connect the Secure Element U40 to the SCI7.\
                                                                        The SCI7 needs to be programmed for Smart Card Interface  */

#define     LCD_DATA11_B_PIN            IOPORT_PORT_09_PIN_05   /*  LCD MODULE DATA (R3). RGB565  */
#define     LCD_DATA12_B_PIN            IOPORT_PORT_09_PIN_06   /*  LCD MODULE DATA (R4). RGB565  */
#define     LCD_DATA13_B_PIN            IOPORT_PORT_09_PIN_07   /*  LCD MODULE DATA (R5). RGB565  */
#define     LCD_DATA14_B_PIN            IOPORT_PORT_09_PIN_08   /*  LCD MODULE DATA (R6). RGB565  */

#define     MCU_PMOD5_IO7_PIN           IOPORT_PORT_09_PIN_09   /*  PMOD 5 GPIO 7  */
#define     WL_PWR_EN_PIN               IOPORT_PORT_09_PIN_10   /*  WIFI Power Enable. Active High  */
#define     LCD_DISP_PIN                IOPORT_PORT_09_PIN_11   /*  LCD Display ON. Active High  */
#define     SE_RST_PIN                  IOPORT_PORT_09_PIN_12   /*  Secure Element RESET. Only for U37  */

#define     MCU_SDIO_USD_WL_PIN         IOPORT_PORT_09_PIN_13   /*  SDIO MUX selection signal.\
                                                                        High: the SDIO bus is connected to the WIFI Module\
                                                                        Low: the SDIO bus is connected to the µSD Card Connector.  */

#define     BT_EN_PIN                   IOPORT_PORT_09_PIN_14   /*  BlueTooth Enable signal. Active High.  */

#define     LCD_DATA05_B_PIN            IOPORT_PORT_10_PIN_00   /*  LCD MODULE DATA (G2). RGB565  */
#define     LCD_DATA06_B_PIN            IOPORT_PORT_10_PIN_01   /*  LCD MODULE DATA (G3). RGB565  */
#define     TXD7_B_MOSI7_B_SDA7_B_PIN   IOPORT_PORT_10_PIN_02   /*  PMOD 1: UART TX / SPI MOSI / I2C SDA  */
#define     RXD7_B_MISO7_B_SCL7_B_PIN   IOPORT_PORT_10_PIN_03   /*  PMOD 1: UART RX / SPI MISO / I2C SCL  */
#define     SCK7_B_PIN                  IOPORT_PORT_10_PIN_04   /*  PMOD 1: SPI SCK /Synchronous UART Clock  */
#define     CTS7_RTS7_B_SS7_B_PIN       IOPORT_PORT_10_PIN_05   /*  PMOD 1: SPI CS  */
#define     FLASH_CS_PIN                IOPORT_PORT_10_PIN_06   /*  External Serial Flash Chip Select  */
#define     NFC_CS_PIN                  IOPORT_PORT_10_PIN_07   /*  NFC Chip Select  */
#define     LCD_DATA09_B_PIN            IOPORT_PORT_10_PIN_08   /*  LCD MODULE DATA (G6). RGB565  */
#define     LCD_DATA08_B_PIN            IOPORT_PORT_10_PIN_09   /*  LCD MODULE DATA (G5). RGB565  */
#define     LCD_DATA07_B_PIN            IOPORT_PORT_10_PIN_10   /*  LCD MODULE DATA (G4). RGB565  */

#define     TCLK_PIN                    IOPORT_PORT_10_PIN_12   /*  Debug Trace Clock  */
#define     TDATA0_PIN                  IOPORT_PORT_10_PIN_13   /*  Debug Trace Data 0  */
#define     TDATA1_PIN                  IOPORT_PORT_10_PIN_14   /*  Debug Trace Data 1  */
#define     TDATA2_PIN                  IOPORT_PORT_10_PIN_15   /*  Debug Trace Data 2  */
#define     USBHS_VBUSEN_PIN            IOPORT_PORT_11_PIN_00   /*  USB Host High-Speed VBUS Enable  */
#define     USBHS_VBUS_PIN              IOPORT_PORT_11_PIN_01   /*  USB Host High-Speed VBUS Detection  */
#define     CTS8_RTS8_B_SS8_B_PIN       IOPORT_PORT_11_PIN_02   /*  PMOD 2: UART TX / SPI MOSI / I2C SDA  */
#define     SCK8_B_PIN                  IOPORT_PORT_11_PIN_03   /*  PMOD 2: UART RX / SPI MISO / I2C SCL  */
#define     TXD8_B_MOSI8_B_SDA8_B_PIN   IOPORT_PORT_11_PIN_04   /*  PMOD 2: SPI SCK /Synchronous UART Clock  */
#define     RXD8_B_MISO6_B_SCL6_B_PIN   IOPORT_PORT_11_PIN_05   /*  PMOD 2: SPI CS  */
#define     LED1_PIN                    IOPORT_PORT_11_PIN_06   /*  LED 1 (Green). Active High  */
#define     LED2_PIN                    IOPORT_PORT_11_PIN_07   /*  LED 2 (Blue). Active High  */


/*IO Expanders pins*/

/*IO expander 0*/
/*Port 0*/
#define     PMOD4_RST                   IOEXP_0_PORT_0_PIN_0   /*  PMOD 4: Reset  */
#define     PMOD3_RST                   IOEXP_0_PORT_0_PIN_1   /*  PMOD 3: Reset  */
#define     PMOD2_RST                   IOEXP_0_PORT_0_PIN_2   /*  PMOD 2: Reset  */
#define     PMOD1_RST                   IOEXP_0_PORT_0_PIN_3   /*  PMOD 1: Reset  */
#define     PMOD4_UART_SPI_I2C          IOEXP_0_PORT_0_PIN_4   /*  PMOD 4: UART-SPI / nI2C  */
#define     PMOD3_UART_SPI_I2C          IOEXP_0_PORT_0_PIN_5   /*  PMOD 3: UART-SPI / nI2C  */
#define     PMOD2_UART_SPI_I2C          IOEXP_0_PORT_0_PIN_6   /*  PMOD 2: UART-SPI / nI2C  */
#define     PMOD1_UART_SPI_I2C          IOEXP_0_PORT_0_PIN_7   /*  PMOD 1: UART-SPI / nI2C  */
/*Port 1*/
#define     PMOD4_IO7                   IOEXP_0_PORT_1_PIN_0   /*  PMOD 4: General Purpose I/O 7  */
#define     PMOD4_IO8                   IOEXP_0_PORT_1_PIN_1   /*  PMOD 4: General Purpose I/O 8  */
#define     PMOD3_IO7                   IOEXP_0_PORT_1_PIN_2   /*  PMOD 3: General Purpose I/O 7  */
#define     PMOD3_IO8                   IOEXP_0_PORT_1_PIN_3   /*  PMOD 3: General Purpose I/O 8  */
#define     PMOD2_IO7                   IOEXP_0_PORT_1_PIN_4   /*  PMOD 2: General Purpose I/O 7  */
#define     PMOD2_IO8                   IOEXP_0_PORT_1_PIN_5   /*  PMOD 2: General Purpose I/O 8  */
#define     PMOD1_IO7                   IOEXP_0_PORT_1_PIN_6   /*  PMOD 1: General Purpose I/O 7  */
#define     PMOD1_IO8                   IOEXP_0_PORT_1_PIN_7   /*  PMOD 1: General Purpose I/O 8  */


/*IO expander 1*/
/*Port 0 */
#define     PMOD1_PWR                   IOEXP_1_PORT_0_PIN_1   /*  PMOD 1: Power  */
#define     PMOD2_PWR                   IOEXP_1_PORT_0_PIN_2   /*  PMOD 2: Power  */
#define     PMOD3_PWR                   IOEXP_1_PORT_0_PIN_3   /*  PMOD 3: Power  */
#define     PMOD4_PWR                   IOEXP_1_PORT_0_PIN_4   /*  PMOD 4: Power  */
#define     PMOD5_PWR                   IOEXP_1_PORT_0_PIN_5   /*  PMOD 5: Power  */
#define     PMOD6_PWR                   IOEXP_1_PORT_0_PIN_6   /*  PMOD 6: Power  */
/*Port 1*/
#define     BTN1_PIN                    IOEXP_1_PORT_1_PIN_2   /*  Button SW1 input  */
#define     BTN2_PIN                    IOEXP_1_PORT_1_PIN_3   /*  Button SW2 input  */
#define     BTN3_PIN                    IOEXP_1_PORT_1_PIN_4   /*  Button SW3 input  */
#define     BTN4_PIN                    IOEXP_1_PORT_1_PIN_5   /*  Button SW4 input  */
#define     SE_I2C_BUS_EN               IOEXP_1_PORT_1_PIN_6   /*  Secure element I2C Bus Enable  */
#define     WL_RESET                    IOEXP_1_PORT_1_PIN_7   /*  Wireless Lan Reset  */

#endif /* GW002_PIN_CONFIG_H */
