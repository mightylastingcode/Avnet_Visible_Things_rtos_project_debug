#include "pmod_configure_thread.h"
#include <pca9535/pca9535.h>
//  v2: removed SSP_SUPPRESS_ISR_g_i2c0 because this is only required when you have more than one instance of
//      the i2c driver.   If you only have one, then you would not want to have it.  Because it will tell
//      the compiler to hide the only ISR definition you have.   So, you have no ISR handle.   That is why I get
//      the SSP_ERR_IRQ_BSP_DISABLED error.  (From Future Alex Grutter.

//      fix the channel of framework shared bus to 3 (This is a second place that I need to specify the channel
//      correctly.
//
//  v3: add void write_PMOD1_output (uint8_t portdata);
//  v4: add u19 i2c driver and enable pmod vcc.   Need to add u19 open/read/write back or I get SSP_ERR_ASSERTION
//      (!SSP_SUCCESS) or 1.
//  v5: pca9535.h/c are succesfully created.
//  v6: move more subroutines into pca9535.c file.


/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/


ssp_err_t setup_pmod1_gpio(void);
void write_PMOD1_output (uint8_t portdata);



/* PMOD Configure Thread entry function */
void pmod_configure_thread_entry(void)
{
    ssp_err_t err;

    err = g_sf_i2c_io_exp_u18.p_api->open(g_sf_i2c_io_exp_u18.p_ctrl,g_sf_i2c_io_exp_u18.p_cfg);
    if (err)
            g_ioport.p_api->pinWrite(LEDREDPIN, true);

    err = setup_pmod1_gpio();

    write_PMOD1_output(0x55);
    write_PMOD1_output(0xAA);

    while (true)
    {
        write_PMOD1_output(0x66);
        write_PMOD1_output(0x99);
        tx_thread_sleep(TX_TIMER_TICKS_PER_SECOND/100*2);

    }
}

//
// setup pmod1 for 8 GPIO
// IO.1 PA05 (S7G2)
// IO.2 PA04
// IO.3 PA03
// IO.4 PA02
// IO.5 P400
// IO.6 Reset (U18 IO Expander port 0.7)
// IO.7 IO7 (U18 IO Expander port 1.6)
// IO.8 IO8 (U18 IO Expander port 1.7)

// Configuration U18 COMM = L (port 0.7)
// Direction     U18  Direction (all output)
// Power         U19 port 0.1 = H

ssp_err_t setup_pmod1_gpio(void) {
    ssp_err_t err;          // function return status
    uint8_t register_data;  // data from register read


    // open the driver
    err = pca3535_open(IOEXPANDERU18_IO_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    /////////////////////////////////////////////////////////////////////////////////////

    // change the slave address for U18 expander
    //err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    //if (err)
    //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);


    // write the port 0 configuration register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS,CONFIGREGP0_ADDR,IOEX1_PORT0_CONFIG);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 configuration register port
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, CONFIGREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (IOEX1_PORT0_CONFIG != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 0 output register port  (COMMS Mode bit 4 = L)
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP0_ADDR,0);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (0 != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);


    // write the port 1 configuration register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS, CONFIGREGP1_ADDR,IOEX1_PORT1_CONFIG);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 1 configuration register port
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, CONFIGREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (IOEX1_PORT1_CONFIG != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 1 output register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP1_ADDR,0);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (0 != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    /////////////////////////////////////////////////////////////////////////////////////
    // We only need to configure the pins as output pins.
    // The default value of the output registers is already '1'.
    // So, there is no need to write '1' to the output registers.

     // change the slave address for U19 expander
     //err = pca3535_setslaveaddress(IOEXPANDER2_PWR_SLAVEADDRESS);
     //if (err)
     //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // open the driver
    err = pca3535_open(IOEXPANDERU19_PWR_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // write the port 0 configuration register port
     err = pca3535_register_write(IOEXPANDERU19_PWR_SLAVEADDRESS,CONFIGREGP0_ADDR,IOEX2_PORT0_CONFIG);
     if (err)
         g_ioport.p_api->pinWrite(LEDREDPIN, true);

     // read the port 0 configuration register port
     err = pca3535_register_read(IOEXPANDERU19_PWR_SLAVEADDRESS,CONFIGREGP0_ADDR, &register_data);
     if (err)
         g_ioport.p_api->pinWrite(LEDREDPIN, true);
     if (IOEX2_PORT0_CONFIG != register_data)        // data verify
         g_ioport.p_api->pinWrite(LEDORGPIN, true);

     return (err);


}

void write_PMOD1_output (uint8_t portdata) {
    ssp_err_t err;          // function return status
    uint8_t write_data;  // data to be written into the register
    uint8_t read_data;   // data to be red from the register

    if (portdata & 0x01)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO1, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO1, IOPORT_LEVEL_LOW);

    if (portdata & 0x02)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO2, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO2, IOPORT_LEVEL_LOW);

    if (portdata & 0x04)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO3, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO3, IOPORT_LEVEL_LOW);

    if (portdata & 0x08)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO4, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO4, IOPORT_LEVEL_LOW);

    if (portdata & 0x10)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO5, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO5, IOPORT_LEVEL_LOW);

    // change the slave address for U18 expander
    //err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    //if (err)
    //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // read the port 0 input register port
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP0_ADDR, &read_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    write_data = read_data;   // copy the current state of the port.

    if (portdata & 0x20)
        write_data |= PMOD1_GPIO_IO6_MASK;   // set IO6
    else
        write_data &=(uint8_t) (~(PMOD1_GPIO_IO6_MASK)); // clear IO6

    // write the port 0 output register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP0_ADDR,write_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 1 output register port
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP1_ADDR, &read_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    write_data = read_data;   // copy the current state of the port.

    if (portdata & 0x40)
        write_data |= PMOD1_GPIO_IO7_MASK;   // set IO7
    else
        write_data &= (uint8_t)(~(PMOD1_GPIO_IO7_MASK)); // clear IO7

    if (portdata & 0x80)
        write_data |= PMOD1_GPIO_IO8_MASK;   // set IO8
    else
        write_data &= (uint8_t)(~(PMOD1_GPIO_IO8_MASK)); // clear IO8

    // write the port 1 output register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS,OUTPUTPORTREGP1_ADDR,write_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);


}



