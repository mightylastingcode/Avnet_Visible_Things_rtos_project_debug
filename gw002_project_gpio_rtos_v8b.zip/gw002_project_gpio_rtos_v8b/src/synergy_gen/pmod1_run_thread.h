/* generated thread header file - do not edit */
#ifndef PMOD1_RUN_THREAD_H_
#define PMOD1_RUN_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus 
extern "C" void pmod1_run_thread_entry(void);
#else 
extern void pmod1_run_thread_entry(void);
#endif
#ifdef __cplusplus
extern "C"
{
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* PMOD1_RUN_THREAD_H_ */
