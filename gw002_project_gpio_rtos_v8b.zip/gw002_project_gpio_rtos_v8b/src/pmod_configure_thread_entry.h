/*
 * pmod_configure_thread_entry.h
 *
 *  Created on: Mar 29, 2018
 *      Author: mikel
 */

#ifndef PMOD_CONFIGURE_THREAD_ENTRY_H_
#define PMOD_CONFIGURE_THREAD_ENTRY_H_

#include "pmod_configure_thread.h"  // so event flags object visible to all threads.

#define IOEXP_DONE_EVENT_FLAG 1

#endif /* PMOD_CONFIGURE_THREAD_ENTRY_H_ */
