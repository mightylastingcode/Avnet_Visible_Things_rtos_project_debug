#include "pmod_thread.h"

/* PMOD Thread entry function */
void pmod_thread_entry(void)
{
    /* TODO: add your own code here */
    while (1)
    {
        tx_thread_sleep (1);
    }
}
