/* generated thread header file - do not edit */
#ifndef PMOD_CONFIGURE_THREAD_H_
#define PMOD_CONFIGURE_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus 
extern "C" void pmod_configure_thread_entry(void);
#else 
extern void pmod_configure_thread_entry(void);
#endif
#include "r_sci_i2c.h"
#include "r_i2c_api.h"
#include "sf_i2c.h"
#include "sf_i2c_api.h"
#ifdef __cplusplus
extern "C"
{
#endif
extern const i2c_cfg_t g_i2c0_cfg;
/** I2C on SCI Instance. */
extern const i2c_master_instance_t g_i2c0;
#ifndef NULL
void NULL(i2c_callback_args_t * p_args);
#endif
/* SF I2C on SF I2C Instance. */
extern const sf_i2c_instance_t g_sf_i2c_io_exp_u18;
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* PMOD_CONFIGURE_THREAD_H_ */
