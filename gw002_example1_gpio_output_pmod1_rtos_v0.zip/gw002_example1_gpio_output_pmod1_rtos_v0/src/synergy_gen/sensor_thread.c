/* generated thread source file - do not edit */
#include "sensor_thread.h"

TX_THREAD sensor_thread;
void sensor_thread_create(void);
static void sensor_thread_func(ULONG thread_input);
/** Alignment requires using pragma for IAR. GCC is done through attribute. */
#if defined(__ICCARM__)
#pragma data_alignment = BSP_STACK_ALIGNMENT
#endif
static uint8_t sensor_thread_stack[1024] BSP_PLACE_IN_SECTION(".stack.sensor_thread") BSP_ALIGN_VARIABLE(BSP_STACK_ALIGNMENT);
#if !defined(SSP_SUPPRESS_ISR_g_i2c1) && !defined(SSP_SUPPRESS_ISR_SCI3)
SSP_VECTOR_DEFINE_CHAN(sci_i2c_rxi_isr, SCI, RXI, 3);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c1) && !defined(SSP_SUPPRESS_ISR_SCI3)
SSP_VECTOR_DEFINE_CHAN(sci_i2c_txi_isr, SCI, TXI, 3);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c1) && !defined(SSP_SUPPRESS_ISR_SCI3)
SSP_VECTOR_DEFINE_CHAN(sci_i2c_tei_isr, SCI, TEI, 3);
#endif
sci_i2c_instance_ctrl_t g_i2c1_ctrl;

/** I2C extended configuration */
const sci_i2c_extended_cfg g_i2c1_cfg_extend =
{ .bitrate_modulation = true };

const i2c_cfg_t g_i2c1_cfg =
{ .channel = 3, .rate = I2C_RATE_STANDARD, .slave = 0x27, .addr_mode = I2C_ADDR_MODE_7BIT, .sda_delay = 300,
#define SYNERGY_NOT_DEFINED (1)            
#if (SYNERGY_NOT_DEFINED == SYNERGY_NOT_DEFINED)
  .p_transfer_tx = NULL,
#else
  .p_transfer_tx = &SYNERGY_NOT_DEFINED,
#endif
#if (SYNERGY_NOT_DEFINED == SYNERGY_NOT_DEFINED)
  .p_transfer_rx = NULL,
#else
  .p_transfer_rx = &SYNERGY_NOT_DEFINED,
#endif
#undef SYNERGY_NOT_DEFINED
  .p_callback = NULL,
  .p_context = (void *) &g_i2c1, .rxi_ipl = (2), .txi_ipl = (2), .tei_ipl = (2), .eri_ipl = BSP_IRQ_DISABLED,
  .p_extend = &g_i2c1_cfg_extend, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c1 =
{ .p_ctrl = &g_i2c1_ctrl, .p_cfg = &g_i2c1_cfg, .p_api = &g_i2c_master_on_sci };
sf_i2c_instance_ctrl_t g_sf_i2c_io_exp_u19_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c1_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_io_exp_u19_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_i2c1_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_io_exp_u19 =
{ .p_ctrl = &g_sf_i2c_io_exp_u19_ctrl, .p_cfg = &g_sf_i2c_io_exp_u19_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;
void g_hal_init(void);

void sensor_thread_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */

    tx_thread_create (&sensor_thread, (CHAR *) "Sensor Thread", sensor_thread_func, (ULONG) NULL, &sensor_thread_stack,
                      1024, 2, 2, 1, TX_AUTO_START);
}

static void sensor_thread_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* First thread will take care of common initialization. */
    UINT err;
    err = tx_semaphore_get (&g_ssp_common_initialized_semaphore, TX_WAIT_FOREVER);

    while (TX_SUCCESS != err)
    {
        /* Check err, problem occurred. */
        BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
    }

    /* Only perform common initialization if this is the first thread to execute. */
    if (false == g_ssp_common_initialized)
    {
        /* Later threads will not run this code. */
        g_ssp_common_initialized = true;

        /* Perform common module initialization. */
        g_hal_init ();

        /* Now that common initialization is done, let other threads through. */
        /* First decrement by 1 since 1 thread has already come through. */
        g_ssp_common_thread_count--;
        while (g_ssp_common_thread_count > 0)
        {
            err = tx_semaphore_put (&g_ssp_common_initialized_semaphore);

            while (TX_SUCCESS != err)
            {
                /* Check err, problem occurred. */
                BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
            }

            g_ssp_common_thread_count--;
        }
    }

    /* Initialize each module instance. */

    /* Enter user code for this thread. */
    sensor_thread_entry ();
}
