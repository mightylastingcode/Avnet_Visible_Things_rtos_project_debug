#include "pmod_configure_thread.h"

/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/
// GPIO Type 1
#define PMOD1_GPIO_IO1  IOPORT_PORT_10_PIN_05
#define PMOD1_GPIO_IO2  IOPORT_PORT_10_PIN_02
#define PMOD1_GPIO_IO3  IOPORT_PORT_10_PIN_03
#define PMOD1_GPIO_IO4  IOPORT_PORT_10_PIN_04
#define PMOD1_GPIO_IO5  IOPORT_PORT_04_PIN_00
#define PMOD1_GPIO_IO6_MASK  0B00001000     // port 0
#define PMOD1_GPIO_IO7_MASK  0B01000000     // port 1
#define PMOD1_GPIO_IO8_MASK  0B10000000     // port 1

#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

#define IOEXPANDERU18_IO_SLAVEADDRESS     0x25   // control IO<8:6> and COMMS Mode for different PMOD types. (1x6,1x12,2x4)
#define IOEXPANDERU19_PWR_SLAVEADDRESS    0x27   // control PMOD power, buttons, secure element

// PCA9535 IO Expander: Internal registers
#define INPUTPORTREGP0_ADDR     0
#define INPUTPORTREGP1_ADDR     1
#define OUTPUTPORTREGP0_ADDR    2
#define OUTPUTPORTREGP1_ADDR    3
#define POLARITYINVREGP0_ADDR   4
#define POLARITYINVREGP1_ADDR   5
#define CONFIGREGP0_ADDR        6
#define CONFIGREGP1_ADDR        7

// IO Expander 1
// PORT 0 - 0=output, 1=input
// bit 0  PMOD4 RESET pin
// bit 1  PMOD3 RESET pin
// bit 2  PMOD2 RESET pin
// bit 3  PMOD1 RESET pin
// bit 4  PMOD4 COMMS Mode pin (Output only)
// bit 5  PMOD3 COMMS Mode pin (Output only)
// bit 6  PMOD2 COMMS Mode pin (Output only)
// bit 7  PMOD1 COMMS Mode pin (Output only)
#define IOEX1_PORT0_CONFIG        0b00000000   // all output

// IO Expander 1
// PORT 1 - 0=output, 1=input
// bit 0  PMOD4 IO7 pin
// bit 1  PMOD4 IO8 pin
// bit 2  PMOD3 IO7 pin
// bit 3  PMOD3 IO8 pin
// bit 4  PMOD2 IO7 pin
// bit 5  PMOD2 IO8 pin
// bit 6  PMOD1 IO7 pin
// bit 7  PMOD1 IO8 pin

#define IOEX1_PORT1_CONFIG        0b00000000   // all output

// PORT 1
#define PMOD1COM_CLR        0b01111111    // for bit and operation
#define PMOD1COM_SET        0b10000000    // for bit or operation

/* reset is IO6 */
#define PMOD1RESET_CLR      0b11110111    // for bit and operation
#define PMOD1RESET_SET      0b00001000    // for bit or operation

#define PMOD1IO6_CLR      0b11110111    // for bit and operation
#define PMOD1IO6_SET      0b00001000    // for bit or operation

// PORT 2
#define PMOD1IO7_CLR      0b10111111    // for bit and operation
#define PMOD1IO7_SET      0b01000000    // for bit or operation

#define PMOD1IO8_CLR      0b01111111    // for bit and operation
#define PMOD1IO8_SET      0b10000000    // for bit or operation

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/


void setup_pmod1_gpio(void);

ssp_err_t pca3535_open(uint8_t slaveaddr);
ssp_err_t pca3535_register_write(uint8_t slaveaddr, uint8_t regaddr, uint8_t regdata);
ssp_err_t pca3535_register_read(uint8_t slaveaddr, uint8_t regaddr, uint8_t *regdata);


/* PMOD Configure Thread entry function */
void pmod_configure_thread_entry(void)
{
    ssp_err_t err;

    err = g_sf_i2c_io_exp_u18.p_api->open(g_sf_i2c_io_exp_u18.p_ctrl,g_sf_i2c_io_exp_u18.p_cfg);
    if (err)
            g_ioport.p_api->pinWrite(LEDREDPIN, true);

    setup_pmod1_gpio();

    while (1)
    {
        tx_thread_sleep (1);
    }
}

//
// setup pmod1 for 8 GPIO
// IO.1 PA05 (S7G2)
// IO.2 PA04
// IO.3 PA03
// IO.4 PA02
// IO.5 P400
// IO.6 Reset (U18 IO Expander port 0.7)
// IO.7 IO7 (U18 IO Expander port 1.6)
// IO.8 IO8 (U18 IO Expander port 1.7)

// Configuration U18 COMM = L (port 0.7)
// Direction     U18  Direction (all output)
// Power         U19 port 0.1 = H

void setup_pmod1_gpio(void) {
    ssp_err_t err;          // function return status
    uint8_t register_data;  // data from register read


    // open the driver
    err = pca3535_open(IOEXPANDERU18_IO_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    /////////////////////////////////////////////////////////////////////////////////////

    // change the slave address for U18 expander
    //err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    //if (err)
    //    g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);


    // write the port 0 configuration register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS,CONFIGREGP0_ADDR,IOEX1_PORT0_CONFIG);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 configuration register port
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, CONFIGREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (IOEX1_PORT0_CONFIG != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 0 output register port  (COMMS Mode bit 4 = L)
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP0_ADDR,0);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (0 != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);


    // write the port 1 configuration register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS, CONFIGREGP1_ADDR,IOEX1_PORT1_CONFIG);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 1 configuration register port
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, CONFIGREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (IOEX1_PORT1_CONFIG != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 1 output register port
    err = pca3535_register_write(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP1_ADDR,0);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(IOEXPANDERU18_IO_SLAVEADDRESS, OUTPUTPORTREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (0 != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

}



// Open the driver
ssp_err_t pca3535_open(uint8_t slaveaddr) {
    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        return (g_sf_i2c_io_exp_u18.p_api->open(g_sf_i2c_io_exp_u18.p_ctrl,g_sf_i2c_io_exp_u18.p_cfg));
    else
        return (!SSP_SUCCESS);

}

// Write a byte to a register
ssp_err_t pca3535_register_write(uint8_t slaveaddr, uint8_t regaddr, uint8_t regdata) {
    uint8_t buf[2]; // buffer to hold command, write data

    buf[0] = regaddr;
    buf[1] = regdata;

    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        return(g_sf_i2c_io_exp_u18.p_api->write(g_sf_i2c_io_exp_u18.p_ctrl, buf, 2, false, TX_WAIT_FOREVER));
    else
        return (!SSP_SUCCESS);
}

// Read a byte from a register
ssp_err_t pca3535_register_read(uint8_t slaveaddr, uint8_t regaddr, uint8_t *regdata) {
    uint8_t buf[2]; // buffer to hold command, write data
    ssp_err_t err;   // function return status

    // write the register address
    buf[0] = regaddr;
    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        err = g_sf_i2c_io_exp_u18.p_api->write(g_sf_i2c_io_exp_u18.p_ctrl, buf, 1, false, TX_WAIT_FOREVER);
    else
        err = !SSP_SUCCESS;

    // read the register byte
    if (SSP_SUCCESS == err){
        if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
            err = g_sf_i2c_io_exp_u18.p_api->read(g_sf_i2c_io_exp_u18.p_ctrl, regdata, 1, false, TX_WAIT_FOREVER);
        else
            err = !SSP_SUCCESS;
    }
    return err;
}
