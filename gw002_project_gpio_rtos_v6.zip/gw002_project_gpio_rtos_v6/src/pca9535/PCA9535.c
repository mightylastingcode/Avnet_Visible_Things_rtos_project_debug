/*
 * PCA9535.c
 *
 *  Created on: Mar 28, 2018
 *      Author: mikel
 */
#include "hal_data.h"
#include "pmod_configure_thread.h"
#include <pca9535/pca9535.h>


// Open the driver
ssp_err_t pca3535_open(uint8_t slaveaddr) {
    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        return (g_sf_i2c_io_exp_u18.p_api->open(g_sf_i2c_io_exp_u18.p_ctrl,g_sf_i2c_io_exp_u18.p_cfg));
    else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
        return (g_sf_i2c_io_exp_u19.p_api->open(g_sf_i2c_io_exp_u19.p_ctrl,g_sf_i2c_io_exp_u19.p_cfg));
    else
        return (!SSP_SUCCESS);

}

// Write a byte to a register
ssp_err_t pca3535_register_write(uint8_t slaveaddr, uint8_t regaddr, uint8_t regdata) {
    uint8_t buf[2]; // buffer to hold command, write data

    buf[0] = regaddr;
    buf[1] = regdata;

    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        return(g_sf_i2c_io_exp_u18.p_api->write(g_sf_i2c_io_exp_u18.p_ctrl, buf, 2, false, TX_WAIT_FOREVER));
    else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
        return(g_sf_i2c_io_exp_u19.p_api->write(g_sf_i2c_io_exp_u19.p_ctrl, buf, 2, false, TX_WAIT_FOREVER));
    else
        return (!SSP_SUCCESS);   //ERR_ASSERTION
}



// Read a byte from a register
ssp_err_t pca3535_register_read(uint8_t slaveaddr, uint8_t regaddr, uint8_t *regdata) {
    uint8_t buf[2]; // buffer to hold command, write data
    ssp_err_t err;   // function return status

    // write the register address
    buf[0] = regaddr;
    if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
        err = g_sf_i2c_io_exp_u18.p_api->write(g_sf_i2c_io_exp_u18.p_ctrl, buf, 1, false, TX_WAIT_FOREVER);
    else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
        err = g_sf_i2c_io_exp_u19.p_api->write(g_sf_i2c_io_exp_u19.p_ctrl, buf, 1, false, TX_WAIT_FOREVER);
    else
        err = !SSP_SUCCESS;

    // read the register byte
    if (SSP_SUCCESS == err){
        if (IOEXPANDERU18_IO_SLAVEADDRESS == slaveaddr)
            err = g_sf_i2c_io_exp_u18.p_api->read(g_sf_i2c_io_exp_u18.p_ctrl, regdata, 1, false, TX_WAIT_FOREVER);
        else if (IOEXPANDERU19_PWR_SLAVEADDRESS == slaveaddr)
            err = g_sf_i2c_io_exp_u19.p_api->read(g_sf_i2c_io_exp_u19.p_ctrl, regdata, 1, false, TX_WAIT_FOREVER);
        else
            err = !SSP_SUCCESS;
    }
    return err;
}
