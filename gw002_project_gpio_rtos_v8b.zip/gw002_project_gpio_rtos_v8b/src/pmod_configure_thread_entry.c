
//  v2: removed SSP_SUPPRESS_ISR_g_i2c0 because this is only required when you have more than one instance of
//      the i2c driver.   If you only have one, then you would not want to have it.  Because it will tell
//      the compiler to hide the only ISR definition you have.   So, you have no ISR handle.   That is why I get
//      the SSP_ERR_IRQ_BSP_DISABLED error.  (From Future Alex Grutter.

//      fix the channel of framework shared bus to 3 (This is a second place that I need to specify the channel
//      correctly.
//
//  v3: add void write_PMOD1_output (uint8_t portdata);
//  v4: add u19 i2c driver and enable pmod vcc.   Need to add u19 open/read/write back or I get SSP_ERR_ASSERTION
//      (!SSP_SUCCESS) or 1.
//  v5: pca9535.h/c are succesfully created.
//  v6: move more subroutines into pca9535.c file.
//  v7: add the event flag: ioexp_config_done_flag
//  v8: copy new pca9535.c/h from gw002_project_gpio_hal_v1 project
//      write to PMOD 1 port only
//  v8a: Adding the PMOD 2 port.   Two threads are affecting the i/o write.  Need to lock up the port until the byte write to pmod port
//       is completed.
//  v8b Add mutex to lock up the u18 i/o write.


#include "pmod_configure_thread.h"
#include "pmod_configure_thread_entry.h"   // event flag
#include <pca9535/pca9535.h>


/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/
// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

#define CFG_ALL_INPUT       0b11111111
#define SET_CFG_PIN_INPUT   1
#define SET_CFG_PIN_OUTPUT  0

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/
    PMOD_CONFIG_t pmodconf;  // Contain configuration for PMOD

    // each configuration registers for two io expanders (U18/U19)
    U18_PORT0_CONFIGREG_t   u18port0cfg;
    U18_PORT1_CONFIGREG_t   u18port1cfg;
    U18_PORT0_OUTREG_t      u18port0outreg;
    U18_PORT1_OUTREG_t      u18port1outreg;

    U19_PORT0_CONFIGREG_t   u19port0cfg;
    U19_PORT1_CONFIGREG_t   u19port1cfg;
    U19_PORT0_OUTREG_t      u19port0outreg;
    U19_PORT1_OUTREG_t      u19port1outreg;

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
    void initialzie_ioexp_registers(void);
    void setup_ioexp_registers(void);

/*---------------------------------------------------------------------------*
 * Function: pmod_configure_thread_entry
 *---------------------------------------------------------------------------*/


/* PMOD Configure Thread entry function */
void pmod_configure_thread_entry(void)
{
    /////////////////////////////////////////////////
    ///  Configure the IO expander's registers
    /////////////////////////////////////////////////

    initialzie_ioexp_registers();
    setup_ioexp_registers();


    /////////////////////////////////////////////////
    ///  Transfer the U18/U19 configuration to pmodconf
    /////////////////////////////////////////////////

    pmodconf.ioexpreg.u18port0cfg   = u18port0cfg.byte;
    pmodconf.ioexpreg.u18port1cfg   = u18port1cfg.byte;
    pmodconf.ioexpreg.u18port0outreg= u18port0outreg.byte;
    pmodconf.ioexpreg.u18port1outreg= u18port1outreg.byte;

    pmodconf.ioexpreg.u19port0cfg   = u19port0cfg.byte;
    pmodconf.ioexpreg.u19port1cfg   = u19port1cfg.byte;
    pmodconf.ioexpreg.u19port0outreg= u19port0outreg.byte;
    pmodconf.ioexpreg.u19port1outreg= u19port1outreg.byte;

    //////////////////////////////////////////////////
    ///  Main Program start
    /////////////////////////////////////////////////

    g_ioport.p_api->pinWrite(LEDGRNPIN, IOPORT_LEVEL_HIGH);  // turn on green led

    setup_pmod(pmodconf);   // setup pmod1

    tx_event_flags_set(&g_config_done_flags, IOEXP_DONE_EVENT_FLAG, TX_OR);   // Configuration is done.

    while (true)
    {
        tx_thread_sleep(TX_TIMER_TICKS_PER_SECOND/100*2);
    }
}
/*
 *  Assign default value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void initialzie_ioexp_registers(void) {

    /////////////////////////////////////////////////
    ///  U18 Default Setup
    /////////////////////////////////////////////////

    u18port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u18port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u18port0outreg.byte  = 0b00000000;    // default all low's
    u18port1outreg.byte  = 0b00000000;    // default all low's

    u18port0cfg.bit.pmod1_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod2_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod3_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod4_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin

    /////////////////////////////////////////////////
    ///  U19 Default Setup
    /////////////////////////////////////////////////
    ///
    u19port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u19port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u19port0outreg.byte  = 0b00000000;    // default all low's  (all pmod power disabled)
    u19port1outreg.byte  = 0b00000000;    // default all low's

    u19port0cfg.bit.pmod1_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod2_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod3_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod4_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod5_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod6_power = SET_CFG_PIN_OUTPUT;      // set as a output pin

    u19port1cfg.bit.button1 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button2 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button3 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button4 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)

    u19port1cfg.bit.secured_element_en = SET_CFG_PIN_OUTPUT;  // set as a output pin

    u19port0outreg.bit.pmod1_power = 0;  // set power off
    u19port0outreg.bit.pmod2_power = 0;  // set power off
    u19port0outreg.bit.pmod3_power = 0;  // set power off
    u19port0outreg.bit.pmod4_power = 0;  // set power off
    u19port0outreg.bit.pmod5_power = 0;  // set power off
    u19port0outreg.bit.pmod6_power = 0;  // set power off

    u19port1outreg.bit.secured_element_en = 0;  // Secured Element disabled.
}

/*
 *  Assign user setup value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void setup_ioexp_registers(void) {

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD1 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 =001
    //////////////////////////////////////////////////

    u18port0outreg.bit.pmod1_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod1_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod1_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod1_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod1_reset_io6  = 1;  // make 0010 0000 initially
    u18port1outreg.bit.pmod1_io7        = 0;
    u18port1outreg.bit.pmod1_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD1 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod1_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD2 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 = 010
    /////////////////////////////////////////////////

    u18port0outreg.bit.pmod2_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod2_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod2_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod2_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod2_reset_io6  = 0;  // make 0100 0000 initially
    u18port1outreg.bit.pmod2_io7        = 1;
    u18port1outreg.bit.pmod2_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD2 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod2_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD3 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 =011
    //////////////////////////////////////////////////

    u18port0outreg.bit.pmod3_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod3_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod3_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod3_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod3_reset_io6  = 1;  // make 0110 0000 initially
    u18port1outreg.bit.pmod3_io7        = 1;
    u18port1outreg.bit.pmod3_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD3 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod3_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD4 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 =100
    /////////////////////////////////////////////////

    u18port0outreg.bit.pmod4_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod4_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod4_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod4_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod4_reset_io6  = 0;  // make 1000 0000 initially
    u18port1outreg.bit.pmod4_io7        = 0;
    u18port1outreg.bit.pmod4_io8        = 1;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD4 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod4_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD5 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod5_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD6 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod6_power = 1;  // pmod1 power enabled.

}
/*-------------------------------------------------------------------------*
 * End of File:  pmod_configure_thread_entry.c
 *-------------------------------------------------------------------------*/
