
/*

    File:    Example 1: Write an 8 bit data to any PMOD (1-6) (GPIO Type 1).
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    3/19/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Set 8 GPIO output on PMOD1.   Write different values to PMOD1 for testing purpose.

    <GPIO Type 1 Pmod>  Example

     IO.1 PA05 (S7G2)
     IO.2 PA04 (S7G2)
     IO.3 PA03 (S7G2)
     IO.4 PA02 (S7G2)
     IO.5 P400 (S7G2)
     IO.6 Reset (U18 IO Expander port 0.7)
     IO.7 IO7 (U18 IO Expander port 1.6)
     IO.8 IO8 (U18 IO Expander port 1.7)


     Configuration U18 port 0.7 COMM = L
     Direction     U18 port0/1 Direction (all output)
     Power         U19 port 0.1 = H (Enable PMOD1 VCC)


     Note: PMOD6 : It has only 4 IO pins.
           IO5 of PMOD[2-6] cannot be configured as output pins due to S7G2 P00x's restriction.

    revision:
    v1 creation : pmod1 only
    v1a : cover u19 port 1 too even if I am not using it at this point.
    v1b : expand the class type to include byte and bit fields.
    v1c : the reduce the complexity of the u18/u19 register write/read by using loop.
    v1d : use the register class type to prepare the change for v1e
    v1e : set/clear the bit in the register. (not yet)
    v2  : create two subroutines to make the main program simpler.
    v2a : assign IO location to pin array.
    v2b : use bit location instead of mask to set/clear IO6/7/8.
    v2c : ??
    v2d : tested with PMOD1 & PMOD2.  Good. Remember PMOD2.IO6 cannot
          be set as output on S7G2.
    v2e : Test all 6 PMOD ports successfully.  Initial value, modified value, and power enabled.
          Configure S7G2 pins as output pins for all 6 PMOD ports.

 *
 *
*/

/* HAL-only entry function */

/*-------------------------------------------------------------------------*
 * Includes:
 *-------------------------------------------------------------------------*/

#include "hal_data.h"
#include <pca9535/pca9535.h>

/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/


// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

#define CFG_ALL_INPUT       0b11111111
#define SET_CFG_PIN_INPUT   1
#define SET_CFG_PIN_OUTPUT  0


/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/

    PMOD_CONFIG_t pmodconf;  // Contain configuration for PMOD

    // each configuration registers for two io expanders (U18/U19)
    U18_PORT0_CONFIGREG_t   u18port0cfg;
    U18_PORT1_CONFIGREG_t   u18port1cfg;
    U18_PORT0_OUTREG_t      u18port0outreg;
    U18_PORT1_OUTREG_t      u18port1outreg;

    U19_PORT0_CONFIGREG_t   u19port0cfg;
    U19_PORT1_CONFIGREG_t   u19port1cfg;
    U19_PORT0_OUTREG_t      u19port0outreg;
    U19_PORT1_OUTREG_t      u19port1outreg;


/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
// Subroutine Prototypes
    void hal_entry(void);

    void initialzie_ioexp_registers(void);
    void setup_ioexp_registers(void);


/*---------------------------------------------------------------------------*
 * Function: hal_entry
 *---------------------------------------------------------------------------*/
/**  Write some 8 bits values to PMOD1.
 *
 */
/*---------------------------------------------------------------------------*/
void hal_entry(void)
{

    /////////////////////////////////////////////////
    ///  Configure the IO expander's registers
    /////////////////////////////////////////////////

    initialzie_ioexp_registers();
    setup_ioexp_registers();


    /////////////////////////////////////////////////
    ///  Transfer the U18/U19 configuration to pmodconf
    /////////////////////////////////////////////////

    pmodconf.ioexpreg.u18port0cfg   = u18port0cfg.byte;
    pmodconf.ioexpreg.u18port1cfg   = u18port1cfg.byte;
    pmodconf.ioexpreg.u18port0outreg= u18port0outreg.byte;
    pmodconf.ioexpreg.u18port1outreg= u18port1outreg.byte;

    pmodconf.ioexpreg.u19port0cfg   = u19port0cfg.byte;
    pmodconf.ioexpreg.u19port1cfg   = u19port1cfg.byte;
    pmodconf.ioexpreg.u19port0outreg= u19port0outreg.byte;
    pmodconf.ioexpreg.u19port1outreg= u19port1outreg.byte;

    //////////////////////////////////////////////////
    ///  Main Program start
    /////////////////////////////////////////////////

    g_ioport.p_api->pinWrite(LEDGRNPIN, IOPORT_LEVEL_HIGH);  // turn on green led

    setup_pmod(pmodconf);   // setup pmod1

    write_pmode_gpio_type1_byte_port (1, 0x1A);

    write_pmode_gpio_type1_byte_port (2, 0xE3);  // for PMOD[1:6] IO<5> (P00x) is only input mode allowed by S7G2.
    //write_pmode_gpio_type1_byte_port (3, 0x64);
    //write_pmode_gpio_type1_byte_port (4, 0xCB);
    //write_pmode_gpio_type1_byte_port (5, 0x27);
    //write_pmode_gpio_type1_byte_port (6, 0x05);
    while (true) {
    }
}


/*
 *  Assign default value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void initialzie_ioexp_registers(void) {

    /////////////////////////////////////////////////
    ///  U18 Default Setup
    /////////////////////////////////////////////////

    u18port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u18port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u18port0outreg.byte  = 0b00000000;    // default all low's
    u18port1outreg.byte  = 0b00000000;    // default all low's

    u18port0cfg.bit.pmod1_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod2_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod3_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u18port0cfg.bit.pmod4_comms = SET_CFG_PIN_OUTPUT;      // set as a output pin

    /////////////////////////////////////////////////
    ///  U19 Default Setup
    /////////////////////////////////////////////////
    ///
    u19port0cfg.byte     = CFG_ALL_INPUT;    // default all input.
    u19port1cfg.byte     = CFG_ALL_INPUT;    // default all input
    u19port0outreg.byte  = 0b00000000;    // default all low's  (all pmod power disabled)
    u19port1outreg.byte  = 0b00000000;    // default all low's

    u19port0cfg.bit.pmod1_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod2_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod3_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod4_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod5_power = SET_CFG_PIN_OUTPUT;      // set as a output pin
    u19port0cfg.bit.pmod6_power = SET_CFG_PIN_OUTPUT;      // set as a output pin

    u19port1cfg.bit.button1 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button2 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button3 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)
    u19port1cfg.bit.button4 = SET_CFG_PIN_OUTPUT;   // set as a output pin (documentation purpose)

    u19port1cfg.bit.secured_element_en = SET_CFG_PIN_OUTPUT;  // set as a output pin

    u19port0outreg.bit.pmod1_power = 0;  // set power off
    u19port0outreg.bit.pmod2_power = 0;  // set power off
    u19port0outreg.bit.pmod3_power = 0;  // set power off
    u19port0outreg.bit.pmod4_power = 0;  // set power off
    u19port0outreg.bit.pmod5_power = 0;  // set power off
    u19port0outreg.bit.pmod6_power = 0;  // set power off

    u19port1outreg.bit.secured_element_en = 0;  // Secured Element disabled.
}

/*
 *  Assign user setup value to IO Expanders' registers
 *
 *  input: None
 *  Return : None
 *
 */
void setup_ioexp_registers(void) {

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD1 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 =001
    //////////////////////////////////////////////////

    u18port0outreg.bit.pmod1_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod1_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod1_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod1_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod1_reset_io6  = 1;  // make 0010 0000 initially
    u18port1outreg.bit.pmod1_io7        = 0;
    u18port1outreg.bit.pmod1_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD1 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod1_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD2 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 = 010
    /////////////////////////////////////////////////

    u18port0outreg.bit.pmod2_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod2_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod2_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod2_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod2_reset_io6  = 0;  // make 0100 0000 initially
    u18port1outreg.bit.pmod2_io7        = 1;
    u18port1outreg.bit.pmod2_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD2 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod2_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD3 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 =011
    //////////////////////////////////////////////////

    u18port0outreg.bit.pmod3_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod3_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod3_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod3_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod3_reset_io6  = 1;  // make 0110 0000 initially
    u18port1outreg.bit.pmod3_io7        = 1;
    u18port1outreg.bit.pmod3_io8        = 0;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD3 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod3_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U18 setup for PMOD4 : GPIO Type 1
    ///                        Set IO6/7/8 output pins
    ///                        Set IO6/7/8 =100
    /////////////////////////////////////////////////

    u18port0outreg.bit.pmod4_comms = 0;   // Low for GPIO Type 1

    u18port0cfg.bit.pmod4_reset_io6 = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod4_io7       = SET_CFG_PIN_OUTPUT;
    u18port1cfg.bit.pmod4_io8       = SET_CFG_PIN_OUTPUT;

    u18port0outreg.bit.pmod4_reset_io6  = 0;  // make 1000 0000 initially
    u18port1outreg.bit.pmod4_io7        = 0;
    u18port1outreg.bit.pmod4_io8        = 1;

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD4 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod4_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD5 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod5_power = 1;  // pmod1 power enabled.

    /////////////////////////////////////////////////
    ///  U19 setup for PMOD6 : Power enabled
    /////////////////////////////////////////////////

    u19port0outreg.bit.pmod6_power = 1;  // pmod1 power enabled.

}
/*-------------------------------------------------------------------------*
 * End of File:  hal_entry.c
 *-------------------------------------------------------------------------*/
